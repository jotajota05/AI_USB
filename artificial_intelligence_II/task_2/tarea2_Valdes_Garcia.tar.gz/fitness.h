#include <vector>

using namespace std;

vector<int> logicAnd(vector<int> chromosome, vector<int> data, int base, int ini, int fin);
int check_1s(vector<int> vec);
vector<float> computeFitness(vector<vector<int> > testData,  vector<vector<int> > pop);

